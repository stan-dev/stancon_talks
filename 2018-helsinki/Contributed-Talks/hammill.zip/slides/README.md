# Analyzing Brain Taxonomy Trees

Slides for my StanCon Helsinki talk on analyzing brain taxonomy
trees.

HTML slides can viewed at:

https://cdn.rawgit.com/cfhammill/2018-08-31_brain-taxonomy-trees-stancon/7591ec69/bayesian-brain-taxonomy-trees.html

PDF slides can be downloaded from this repository:

./hammill-taxonomy-trees.pdf

A video of the talk can be found:

https://www.youtube.com/watch?v=pKZLJPrZLhU&t=139m0s

Large binary files required to regenerate the slide are
available if requested. Send me an email at cfhammill@gmail.com

