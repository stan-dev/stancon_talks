# genexpi-stan
A Bayesian model for inferring genetic regulatoins. Implemented in R with [Stan](http://mc-stan.org/). For a detailed description of the current state of the model, see the file `Rmd/stancon.html` (source code at `Rmd/stancon.Rmd`). For direct viewing, the compiled HTML file is available at http://www.martinmodrak.cz/post/2018-04-18-stancon/stancon.html.
