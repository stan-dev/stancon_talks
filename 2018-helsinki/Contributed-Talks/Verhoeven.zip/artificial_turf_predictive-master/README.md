Stancon Helsinki 2018 resubmission after reviewer feedback.

Requirements:
Rstudio and miktex installed.

Run compile_all_pdfs.R to convert all rmarkdown files into PDFs in the proper order.

# License

Code: copyright 2018, Gertjan Verhoeven, licensed under GPL 3. 
Text: copyright 2018, Gertjan Verhoeven, licensed under CC-BY-NC 4.0.
